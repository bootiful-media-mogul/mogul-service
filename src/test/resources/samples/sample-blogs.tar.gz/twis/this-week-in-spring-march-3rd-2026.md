---
title: " This Week in Spring - March 3rd, 2026"
category: Engineering
publishedAt: 2026-03-03
author: joshlong
---



Hi Spring fans! Welcome to another rip-roaring installment of _This Week in Spring_! I'm writing this in an Uber en route to the airport to get to awsome Atlanta, GA, for Devnexus 2026! Who's goin'? You goin'? We - the Spring team - will be there in force! Come say hi at the boothes or come see our many, many talks there! 

Anyway, I've got a flight to catch so let's dive right into this wonderful week's roundup! 

* this post is _really_ cool: want to make your run-of-the-mill Spring Boot + Tomcat + JPA applications scale a lot higher? Upgrade to Spring Framework 7.0.6, and check out this wonderful blog looking at some low-touch [and very useful advice](https://spring.io/blog/2026/02/25/optimizing-spring-mvc)
* in this post, I look at how to use Device code authorization in an [OAuth context to secure Spring Shell (CLI-powered!) applications](https://youtu.be/rLIQTY9Gg04?si=bQz886KkjEzMdVmK)
* I did a video that looked the [new Spring gRPC 1.0](https://www.youtube.com/watch?v=RRY_d2kZsj0&t=7s)
* Baeldung has a nice post on the [new MCP annotations](https://www.baeldung.com/spring-ai-mcp-annotations) in Spring AI 
* want to learn how to use - to consume  - Anthropic Skills from a Spring AI application? Want to make their deployment, packaging, and reuse even easier? Check out [Spring AI and the new Skillsjars project](https://www.youtube.com/watch?v=eTh1Ti32QDU)
* the Spring Data team is making it easier to reference [properties through typed expressions](https://spring.io/blog/2026/02/27/moving-beyond-strings-in-spring-data) when building queries 
* in last week's installment of _A Bootiful Podcast_, I talked to John Willis, author of ["Rebels of Reason"](https://spring.io/blog/2026/02/26/a-bootiful-podcast-john-willis).
* an interesting blog indeed: how to use [Spring AI and Azure OpenAI](https://dev.to/ayshriv/building-ai-applications-with-spring-ai-and-azure-openai-j6k)
* if you're using Embabel, the agentic framework built on top of Spring AI, [then check out this awesome post talking about agent memory](https://medium.com/embabel/agent-memory-is-not-a-greenfield-problem-ground-it-in-your-existing-data-9272cabe1561)
* our friend Siva has a new Anthropic _skill_ you can use to make [writing sensible, Spring Modulith-based applications a snap](https://x.com/sivalabs/status/2025877821353340946?s=12)
* you've heard that we developed the official Java MCP  SDK, yah? It [was recently ranked as tier 2 across all the SDKs](https://modelcontextprotocol.io/docs/sdk#available-sdks). 
* not to do with Spring, per se, but interesting: a look at [agentic patterns](https://simonwillison.net/2026/Feb/23/agentic-engineering-patterns/)