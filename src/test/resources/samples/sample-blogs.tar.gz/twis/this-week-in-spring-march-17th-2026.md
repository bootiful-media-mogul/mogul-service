---
title: "This Week in Spring - March 17th, 2026"
category: Engineering
publishedAt: 2026-03-17
author: joshlong
---

Hi, Spring fans! Welcome to another rip-roaring installment of _This Week in Spring_, which I'm posting ahead of my keynote at the amazing JavaOne 2026 event here in sunny San Francisco, California!


* I love Piotr's latest post [on using local AI models with LM Studio and Spring AI](https://piotrminkowski.com/2026/03/16/local-ai-models-with-lm-studio-and-spring-ai/)
* Did you see the [new enhanced local variable declaration](https://openjdk.org/jeps/8357464) preview JEP?
* An amazing interview with [Spring Boot team legend Moritz Halbritter](https://www.youtube.com/watch?v=FUFsul26rgA&feature=youtu.be)
* Check out the new [Spring release highlights page!](https://spring.io/projects/release-highlights)
* Java 26 is here! [Check out some of the amazing new features](https://bell-sw.com/blog/an-overview-of-jdk-26-features/)
* Do you use IntelliJ IDEA? You might like the [new JetBrains IntelliJ IDEA documentary!](https://www.youtube.com/watch?v=Kourq_Lz03U) (I'm in it! But don't let that stop you from watching—it’s quite good!)
* Have you registered for this AWS webinar [on building Java AI agents with Spring AI?](https://aws-experience.com/emea/smb/e/f2e47/building-java-ai-agents-with-spring-ai)
* Interesting! [Building a clone of ChatGPT with Spring AI](https://www.youtube.com/watch?v=bHF2F8XcmSs)
* And here's another nice video [on building generative AI solutions with Spring AI](https://www.youtube.com/watch?v=XgN6o_rNXZk)
* I like this: [How to structure your Spring Boot application](https://www.youtube.com/watch?v=ysVDdHXJwPw). If you want a cheat code, check out Spring Modulith :-)