---
title: "This Week in Spring - March 24th, 2026 "
category: Engineering
publishedAt: 2026-03-24
author: joshlong
---

Hi, Spring fans! Welcome to yet another rip-roarin' installment of _This Week in Spring_. As usual, we've got a ton to look into, so let's dive right in!

* Happy 22nd birthday [to Spring Framework, released this day _22 years_ ago!](https://spring.io/blog/2004/03/24/spring-framework-1-0-final-released)
* and of course, next week, 1 April 2026, marks _12 years_ since Spring Boot 1.0 came out!
* [Spring Boot 4.1.0-M3 is available now](https://spring.io/blog/2026/03/20/spring-boot-4-1-0-M3-available-now), with new support for Spring gRPC, file rotation with Log4j, OpenTelemetry improvements, Spring Batch MongoDB support, SSL support for RabbitMQ streams, and AMQP 1.0 support in Spring AMQP! 
* The latest versions of Spring AI and the MCP spec unlock awesome new potential: [MCP applications!](https://spring.io/blog/2026/03/18/mcp-apps)
* In last week's installment of _A Bootiful Podcast_, I talked to legendary Java author, teacher, and professor extraordinaire [Cay Horstmann!](https://spring.io/blog/2026/03/19/a-bootiful-podcast-cay-horstmann). I've read some of his books, and I'd bet money you have too! 
* Heard of OpenClaw? Want something better, built on the bones of a proper scheduling engine like JobRunr? Check out their implementation: [JavaClaw](https://github.com/jobrunr/JavaClaw)!
* I love this slide from last week's incredible edition of JavaOne: [Microsoft runs on Java!](https://x.com/brjavaman/status/2033952290856701972?s=12)
* [Spring Data Valkey 1.0 is here!](https://github.com/valkey-io/spring-data-valkey/releases/tag/v1.0.0)
* [Using local models with Spring AI](https://piotrminkowski.com/2026/03/16/local-ai-models-with-lm-studio-and-spring-ai/)
* [Spring Boot 4.0.4 is available now](https://spring.io/blog/2026/03/19/spring-boot-4-0-4-available-now)
* [Spring Boot 3.5.12 is available now](https://spring.io/blog/2026/03/19/spring-boot-3-5-12-available-now)
* [Spring Security 6.5.9, 7.0.4, and 7.1.0-M3 are all available now](https://spring.io/blog/2026/03/19/spring-security-6-5-9-and-7-0-4-and-7-1-0-M3-available-now)
* [Spring Batch 6.0.3 and 5.2.5 are available now](https://spring.io/blog/2026/03/18/spring-batch-6-0-3-and-5-2-5-available-now)
* [Spring Integration 7.1.0-M3 is available now](https://spring.io/blog/2026/03/18/spring-integration-7-1-0-m3-available)
