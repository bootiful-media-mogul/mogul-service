---
title: " This Week in Spring - March 10th, 2026"
category: Engineering
publishedAt: 2026-03-10
author: joshlong
---



Hi, Spring fans! Welcome to another installment of _This Week in Spring_. As I write this, I am preparing for a trip to Rust, Germany, for one of the best Java conferences in Europe: JavaLand, along with its new companion event, DevLand. It should be fun. Will you be around? If so, say hi.

We have a lot to cover, so let's dive in.

* The Kotlin tutorial has been updated [with information about Spring AI](https://kotlinlang.org/lp/kotlin-spring-ai-tutorial/)
* In last week's installment of _A Bootiful Podcast_, I had the privilege of talking [to Neo4J developer advocate extraordinaire Jennifer Reif](https://spring.io/blog/2026/03/05/a-bootiful-podcast-jennifer-reif)
* Want to secure your Spring Shell CLI-based applications? Check out this video I did [on using Spring Security and OAuth device code grants](https://youtu.be/rLIQTY9Gg04?si=qQMeLiUIz7OHWcin)
* Want to learn more about security? Check out this video looking at [the new Spring Security 7](https://youtu.be/RRY_d2kZsj0?si=2vzMaMsRHJ3MO6Nj)
* In particular, if you want to learn about securing your Spring AI MCP agents, [check out this video](https://youtu.be/Mpd1740f2Vs?si=Sc_-U_3WyZV8srrc)
* AWS is hosting a webinar [on building Java AI agents with Spring AI](https://aws-experience.com/emea/smb/e/f2e47/building-java-ai-agents-with-spring-ai)
* Baeldung has a nice post on [explainable LLM tool call reasoning with Spring AI](https://www.baeldung.com/spring-ai-explainable-agents-capture-llm-tool-call-reasoning)
* Have you checked out the support for consuming Anthropic Skills from within a Spring AI application using the new Spring AI community Skills support? It becomes even more powerful when [paired with the new SkillsJars project](https://youtu.be/eTh1Ti32QDU?si=aNvKv76OdYYnjZo0)
* I also published a full video looking at Spring gRPC 1.0, including setup, building clients and services, observability, security, and more. Watch it [here](https://youtu.be/RRY_d2kZsj0?si=2vzMaMsRHJ3MO6Nj)
* Migrating to modular monoliths [when using Spring Modulith](https://blog.jetbrains.com/idea/2026/02/migrating-to-modular-monolith-using-spring-modulith-and-intellij-idea/)
* A nice [roundup of agentic patterns](https://simonwillison.net/2026/Feb/23/agentic-engineering-patterns/)